# DigiAccountBank — Corporate UI refresh

This update creates a consistent corporate banking design across the Angular application:

- Unified navy, white and teal design tokens in `src/styles.css`.
- Responsive branded navigation for signed-in and signed-out states.
- Redesigned agent sign-in and agent sign-up screens.
- Redesigned customer registration/edit form with clear sections and field validation messages.
- Customer directory colour system aligned with the same design language.
- Existing Angular form bindings, routing, customer CRUD calls and JSON Server endpoints are preserved.

## Run locally

1. Open this folder in VS Code.
2. Run `npm install` if dependencies are not installed.
3. In Terminal 1, run `npm start`.
4. In Terminal 2, run `npx json-server usage.json --port 3000`.
5. Open `http://localhost:4200`.

## Notes

- This is a front-end visual refresh. The application still uses JSON Server as its mock API; it does not become an ASP.NET Core application through styling alone.
- Use fictional test data only. The demo stores agent records and customer data in a local JSON file and is not production-ready for real identity or banking information.
- The Google Fonts import is an optional enhancement; system fallbacks are defined for offline use.
