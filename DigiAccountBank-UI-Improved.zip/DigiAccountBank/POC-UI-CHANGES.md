# DigiAccountBank customer grid improvements

This update changes only the customer dashboard UI and its filtering/sorting logic.

## Changes
- Modern responsive customer directory layout and cleaner table styling.
- First Name, Middle Name and Last Name headers are clickable sort controls.
- Clicking the same name header toggles ascending/descending order.
- Sorting applies to the filtered collection before pagination.
- Search checks first/middle/last name, address type, address lines, city, state, country, PIN code, address-proof type and document number.
- Search is case-insensitive and resets to page 1 when the search term changes.
- Edit and Delete actions are compact and remain on one line.
- Pagination supports Previous/Next and page buttons.

## Run
Terminal 1:
```bash
npm install
npm start
```

Terminal 2, from the DigiAccountBank project folder:
```bash
npx json-server usage.json --port 3000
```

Then open `http://localhost:4200`.

## Important
The application continues to use JSON Server as a mock API. These changes do not add an ASP.NET Core backend.
