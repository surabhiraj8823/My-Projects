import { Component, OnInit, OnDestroy } from '@angular/core';
import { LoginService } from '../services/login.service';
import { User } from '../models/user';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Subject, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

type SortColumn = 'first_name' | 'middle_name' | 'last_name';
type SortDirection = 'asc' | 'desc';

@Component({
  selector: 'app-customer',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit, OnDestroy {
  allUsers: User[] = [];
  filteredUsers: User[] = [];
  searchTerm = '';
  suggestions: string[] = [];
  pageSize = 5;
  currentPage = 1;
  totalPages = 1;

  sortColumn: SortColumn | null = null;
  sortDirection: SortDirection = 'asc';

  private searchSubject = new Subject<string>();
  private searchSubscription?: Subscription;

  constructor(private loginService: LoginService, private router: Router) {}

  ngOnInit(): void {
    this.fetchUsers();

    this.searchSubscription = this.searchSubject.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe((term) => {
      this.searchTerm = term;
      this.currentPage = 1;
      this.onSearchChange();
    });
  }

  ngOnDestroy(): void {
    this.searchSubscription?.unsubscribe();
    this.searchSubject.complete();
  }

  fetchUsers(): void {
    this.loginService.getUsers().subscribe({
      next: (users: User[]) => {
        this.allUsers = users ?? [];
        this.applyFilters();
      },
      error: (error) => {
        console.error('Error fetching users:', error);
        alert('Failed to load users. Please try again later.');
      }
    });
  }

  // Searches across the visible customer-data columns, not only first name.
  applyFilters(): void {
    const term = this.searchTerm.trim().toLocaleLowerCase();

    let users = this.allUsers.filter((user) => {
      if (!term) return true;

      const searchableValues = [
        user.first_name,
        user.middle_name,
        user.last_name,
        user.address?.type,
        user.address?.line1,
        user.address?.line2,
        user.address?.city,
        user.address?.state,
        user.address?.country,
        user.address?.pin_code,
        user.addressProof?.type,
        user.addressProof?.document_number
      ];

      return searchableValues.some(value =>
        String(value ?? '').toLocaleLowerCase().includes(term)
      );
    });

    // Sort the full filtered collection before taking the current page.
    if (this.sortColumn) {
      const column = this.sortColumn;
      const direction = this.sortDirection === 'asc' ? 1 : -1;
      users = [...users].sort((a, b) => {
        const valueA = String(a[column] ?? '').trim().toLocaleLowerCase();
        const valueB = String(b[column] ?? '').trim().toLocaleLowerCase();
        return valueA.localeCompare(valueB, undefined, { sensitivity: 'base' }) * direction;
      });
    }

    this.totalPages = Math.max(1, Math.ceil(users.length / this.pageSize));
    if (this.currentPage > this.totalPages) this.currentPage = this.totalPages;

    const start = (this.currentPage - 1) * this.pageSize;
    this.filteredUsers = users.slice(start, start + this.pageSize);
  }

  sortBy(column: SortColumn): void {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }

    this.currentPage = 1;
    this.applyFilters();
  }

  sortIndicator(column: SortColumn): string {
    if (this.sortColumn !== column) return '↕';
    return this.sortDirection === 'asc' ? '↑' : '↓';
  }

  onPageChange(page: number): void {
    this.currentPage = page;
    this.applyFilters();
  }

  editUser(id: string | number): void {
    this.router.navigate(['/register', id]);
  }

  deleteUser(id: string | number): void {
    if (confirm('Are you sure you want to delete this customer?')) {
      this.loginService.deleteUser(String(id)).subscribe({
        next: () => {
          alert('Customer deleted successfully.');
          this.fetchUsers();
        },
        error: (error) => {
          console.error('Error deleting customer:', error);
          alert('Failed to delete customer. Please try again later.');
        }
      });
    }
  }

  // Suggestions are optional; the actual results search across all displayed data columns.
  onSearchChange(): void {
    const term = this.searchTerm.trim().toLocaleLowerCase();
    if (!term) {
      this.suggestions = [];
      this.applyFilters();
      return;
    }

    const matchedNames = this.allUsers
      .map(user => user.first_name)
      .filter((name): name is string => !!name && name.toLocaleLowerCase().includes(term));

    this.suggestions = Array.from(new Set(matchedNames)).slice(0, 5);
    this.applyFilters();
  }

  selectSuggestion(name: string): void {
    this.searchTerm = name;
    this.suggestions = [];
    this.currentPage = 1;
    this.applyFilters();
  }

  onSearchTermChange(term: string): void {
    this.searchSubject.next(term);
  }

  clearSearch(): void {
    this.searchTerm = '';
    this.suggestions = [];
    this.currentPage = 1;
    this.applyFilters();
  }
}
